package com.example.turismo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;


public class Home extends AppCompatActivity {

    //Arrays con los servicios turisticos
    String[] services={"Hospedaje", "Trasporte", "Parques Naturales", "Parques Acuaticos", "Entretenimiento"};
    String[] products={"Restaurantes", "Viveres", "Lacteos/Amasijos", "Asaderos"};
    String[] events={"Semana Cultural", "Expo-Proyectos", "Comunales", "Intercolegiados"};
    String[] ferias={"Ferias y Fiestas", "Fiesta Campesino", "Virgen del Carmen", "Festival Muncipal"};
    String[] promociones={"Oferta Vacacional", "Tour:Agua Dorada", "Paquetes de viaje"};
    AutoCompleteTextView autoCompleteTxt;
    ArrayAdapter<String>adapterItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        //Metodo para mostrar la lista de servicios
        autoCompleteTxt =findViewById(R.id.list_services);
        adapterItems = new ArrayAdapter<String>(this, R.layout.list_item, services);
        autoCompleteTxt.setAdapter(adapterItems);
        autoCompleteTxt.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            //Acción de dar click sobre los servicios
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), "Item: " + item, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), PanelPrincipal.class);
                startActivity(intent);
            }
        });


        //Metodo para mostrar la lista de los productos
        autoCompleteTxt =findViewById(R.id.list_products);
        adapterItems = new ArrayAdapter<String>(this, R.layout.list_item, products);
        autoCompleteTxt.setAdapter(adapterItems);
        autoCompleteTxt.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"Item: "+item, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), PanelPrincipal.class);
                startActivity(intent);

            }
        });
        //Metodo para mostrar la lista de los eventos
        autoCompleteTxt =findViewById(R.id.list_events);
        adapterItems = new ArrayAdapter<String>(this, R.layout.list_item, events);
        autoCompleteTxt.setAdapter(adapterItems);
        autoCompleteTxt.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"Item: "+item, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), PanelPrincipal.class);
                startActivity(intent);
            }
        });
        //Metodo para mostrar la lista de los ferias
        autoCompleteTxt =findViewById(R.id.list_ferias);
        adapterItems = new ArrayAdapter<String>(this, R.layout.list_item, ferias);
        autoCompleteTxt.setAdapter(adapterItems);
        autoCompleteTxt.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"Item: "+item, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), PanelPrincipal.class);
                startActivity(intent);
            }
        });
        //Metodo para mostrar la lista de las promociones
        autoCompleteTxt =findViewById(R.id.list_promo);
        adapterItems = new ArrayAdapter<String>(this, R.layout.list_item, promociones);
        autoCompleteTxt.setAdapter(adapterItems);
        autoCompleteTxt.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(),"Item: "+item, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), PanelPrincipal.class);
                startActivity(intent);
            }
        });
    }
}