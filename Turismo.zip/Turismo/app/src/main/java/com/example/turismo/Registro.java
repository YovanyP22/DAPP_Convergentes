package com.example.turismo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import com.example.turismo.databinding.ActivityRegistroBinding;

public class Registro extends AppCompatActivity {

    ActivityRegistroBinding binding;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegistroBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        databaseHelper = new DatabaseHelper(this);
        binding.btnRegistro.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                String name = binding.regNombre.getText().toString();
                String lastname = binding.regApellido.getText().toString();
                String email = binding.regEmail.getText().toString();
                String password = binding.regPassword.getText().toString();
                String age = binding.regEdad.getText().toString();

                if (name.equals("") || lastname.equals("") || email.equals("") ||
                        password.equals("") || age.equals(""))
                    Toast.makeText(Registro.this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkUserEmail = databaseHelper.checkEmail(email);
                    if (checkUserEmail == false) {
                        Boolean insert = databaseHelper.insertData(name, lastname, email, password, age);
                        if (insert == true) {
                            Toast.makeText(Registro.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(Registro.this, "Registro fallido", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Registro.this, "El usuario ya existe", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}
